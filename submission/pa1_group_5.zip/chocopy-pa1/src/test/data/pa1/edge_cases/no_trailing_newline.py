def f():
    return