if x:
print(1)
