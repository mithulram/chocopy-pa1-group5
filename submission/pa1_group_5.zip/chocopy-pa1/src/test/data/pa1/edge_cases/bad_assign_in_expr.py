print((x = 1))
