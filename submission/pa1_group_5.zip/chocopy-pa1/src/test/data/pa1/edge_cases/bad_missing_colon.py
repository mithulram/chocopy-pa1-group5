if x
    y = 1
z = 2
