print(x = 1)
