a + b[i][j]
